-- Explicit F11 requests only. Never scans the world or runs a background UObject loop.
local H = require('UEHelpers')
local src = debug.getinfo(1, 'S').source:gsub('^@', '')
local dir = src:match('^(.*[/\\])')
local root = dir .. '../'
local allowed = dofile(dir .. 'catalog.lua')
local request = root .. 'request.txt'
local processing = root .. 'processing.txt'
local status = root .. 'status.txt'
local cancel = root .. 'cancel.txt'
local MAX_QUANTITY, BATCH_SIZE = 1000, 25
local busy = false
-- File-only liveness: no UObject lookup or game-thread work in this loop.
local session = os.time()
local function heartbeat()
    local path = root .. 'heartbeat.txt'
    local f = io.open(path .. '.tmp', 'w')
    if f then
        f:write('1|' .. os.time() .. '|' .. session .. '|LOADED'); f:close()
        os.remove(path); os.rename(path .. '.tmp', path)
    end
    return false
end
heartbeat()
if type(LoopAsync) == 'function' then LoopAsync(3000, function() pcall(heartbeat); return false end) end
-- Explicit F11 only; never cache world objects across calls.
local function soloMode(pc, player)
    if not (pc and pc:IsValid() and player and player:IsValid() and pc:IsLocalController() == true) then return 'WAITING' end
    local system = StaticFindObject('/Script/Engine.Default__KismetSystemLibrary')
    if not (system and system:IsValid()) then return 'WAITING' end
    if system:IsStandalone(pc) == true then return 'SINGLE' end
    if pc:HasAuthority() ~= true then return 'MULTI' end
    local gameplay = StaticFindObject('/Script/Engine.Default__GameplayStatics')
    if not (gameplay and gameplay:IsValid()) then return 'WAITING' end
    local mode = gameplay:GetGameMode(pc)
    if not (mode and mode:IsValid()) then return 'WAITING' end
    local players, spectators = mode:GetNumPlayers(), mode:GetNumSpectators()
    if type(players) ~= 'number' or type(spectators) ~= 'number' or players < 1 or spectators < 0 then return 'WAITING' end
    if players == 1 and spectators == 0 then return 'HOST' end
    return 'MULTI'
end
local function probeWorld()
    local state = 'WAITING'
    local ok = pcall(function()
        local pc, player = H.GetPlayerController(), H.GetPlayer()
        state = soloMode(pc, player)
    end)
    if not ok then state = 'WAITING' end
    local f = io.open(root .. 'world-check.txt', 'w')
    if f then f:write('1|' .. os.time() .. '|' .. session .. '|' .. state); f:close() end
end
local function writeStatus(id, state, count, detail)
    local f = io.open(status, 'w')
    if f then f:write(table.concat({id, state, tostring(count), (tostring(detail or ''):gsub('[\r\n|]', ' '))}, '|')); f:close() end
end
-- A request made before this game start must never execute on a later keypress.
os.remove(request)
os.remove(processing)
writeStatus('-', 'READY', 0, 'F11')
local function process()
    local f = io.open(request, 'r')
    if not f then busy = false; return end
    local text = f:read(512); f:close()
    if not os.rename(request, processing) then busy = false; return end
    local id, timestamp, item, quantity = text:match('^([a-f0-9]+)|(%d+)|([A-Za-z0-9_]+)|(%d+)%s*$')
    local sent, done = 0, false
    local started = os.time()
    local function finish(state, detail)
        if done then return end
        done = true
        writeStatus(id or '-', state, sent, detail)
        os.remove(processing)
        busy = false
    end
    local function cancelled()
        local c = io.open(cancel, 'r')
        if not c then return false end
        local value = c:read(64); c:close()
        return value == id
    end
    local ok, err = pcall(function()
        assert(id and #id == 32, 'Invalid request')
        local age = os.time() - tonumber(timestamp)
        assert(age >= -5 and age <= 120, 'Request expired; prepare again')
        quantity = tonumber(quantity)
        assert(quantity >= 1 and quantity <= MAX_QUANTITY and allowed[item], 'Invalid item or quantity')
        assert(quantity <= BATCH_SIZE or type(ExecuteWithDelay) == 'function', 'Delayed processing unavailable')
        local pc, player = H.GetPlayerController(), H.GetPlayer()
        assert(pc and pc:IsValid() and player and player:IsValid(), 'Enter a single-player world first')
        local controllerAddress, playerAddress = pc:GetAddress(), player:GetAddress()
        local controllerName, playerName = pc:GetFullName(), player:GetFullName()
        -- Keep primitive identity only across delayed callbacks, not UObject wrappers.
        pc, player = nil, nil
        local step
        step = function()
            if done then return end
            local success, why = pcall(function()
                if cancelled() then finish('CANCELLED', 'Requested by user'); return end
                assert(os.time() - started <= 30, 'Request processing timeout')
                local currentPC, currentPlayer = H.GetPlayerController(), H.GetPlayer()
                assert(currentPC and currentPC:IsValid() and currentPlayer and currentPlayer:IsValid(), 'World changed')
                assert(currentPC:GetAddress() == controllerAddress and currentPlayer:GetAddress() == playerAddress and currentPC:GetFullName() == controllerName and currentPlayer:GetFullName() == playerName, 'Player changed; prepare again')
                local mode = soloMode(currentPC, currentPlayer)
                assert(mode == 'SINGLE' or mode == 'HOST', '혼자 플레이하는 호스트인지 확인하지 못했거나 다른 플레이어가 접속했습니다.')
                local lib = StaticFindObject('/Script/Icarus.Default__ItemTemplateLibrary')
                assert(lib and lib:IsValid() and lib:IsValidName(FName(item)) == true, 'Template not available in this game version')
                for i = 1, math.min(BATCH_SIZE, quantity - sent) do
                    assert(currentPC:IsValid() and currentPlayer:IsValid(), 'World changed')
                    currentPC:AddItemToInventory({RowName=FName(item), DataTableName=FName('D_ItemTemplate')})
                    sent = sent + 1
                end
                if sent >= quantity then finish('SENT', item); return end
                writeStatus(id, 'WORKING', sent, quantity)
                ExecuteWithDelay(100, function()
                    local queued, failure = pcall(function() ExecuteInGameThread(step) end)
                    if not queued then finish('ERROR', failure) end
                end)
            end)
            if not success then finish('ERROR', why) end
        end
        step()
    end)
    if not ok then finish('ERROR', err) end
end
RegisterKeyBind(Key.F11, function()
    if busy then return end
    busy = true
    local ok, err = pcall(function()
        ExecuteInGameThread(function()
            probeWorld()
            local success, why = pcall(process)
            if not success then writeStatus('-', 'ERROR', 0, why); busy = false end
        end)
    end)
    if not ok then busy = false; writeStatus('-', 'ERROR', 0, err) end
end)
print('[IcarusSoloItems] Ready: up to 1000 items per request, 25 calls per batch.\n')
